var express = require('express');
var smartfilter = require('../smartfilter-handler/smartfilter.js');
var router = express.Router();

router.post('/connect', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.connect(data, {}, function(result) {
    res.send(result);
  });
});

router.post('/pivot', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.pivot(data, {}, function(result) {
    res.send(result);
  });
});

router.post('/filter', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.filter(data, {}, function(result) {
    res.send(result);
  });
});

router.post('/staticFilter', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.staticFilter(data, {}, function(result) {
    res.send(result);
  });
});

router.post('/removePivot', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.removePivot(data, {}, function(result) {
    res.send(result);
  });
});

router.post('/count', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.count(data, {}, function(result) {
    res.send(result);
  });
});


router.post('/data', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.data(data, {}, function(result) {
    res.send(result);
  });
});

router.post('/flushCache', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.flushCache(data, {}, function(result) {
    res.send(result);
  });
});

router.post('/disconnect', function(req, res, next) {
  var data = JSON.parse(req.body.serializedData);
  smartfilter.disconnect(data, {}, function(result) {
    res.send(result);
  });
});

module.exports = router;
