# Install node dependencies using below command.
npm install


# Install bower dependency using following
cd public
bower install

# Start node application
npm start

# Access application on browser
http://localhost:3000/

######################################################################

Create table using following query in MySQL


CREATE TABLE `newzealand_earthquakes_data` (
  `FID` varchar(500) DEFAULT NULL,
  `publicid` varchar(500) DEFAULT NULL,
  `origintime` varchar(500) DEFAULT NULL,
  `longitude` decimal(18,3) DEFAULT NULL,
  `latitude` decimal(18,3) DEFAULT NULL,
  `depth` decimal(18,3) DEFAULT NULL,
  `magnitude` decimal(18,3) DEFAULT NULL,
  `magnitudetype` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `phases` decimal(18,3) DEFAULT NULL,
  `type` varchar(500) DEFAULT NULL,
  `agency` varchar(500) DEFAULT NULL,
  `updatetime` varchar(500) DEFAULT NULL,
  `origin_geom` varchar(500) DEFAULT NULL,
  `dtg1` datetime DEFAULT NULL,
  `lat` decimal(18,3) DEFAULT NULL,
  `long1` decimal(18,3) DEFAULT NULL,
  `mag` decimal(18,3) DEFAULT NULL
);


Load data from "NewZealandEarthquakes.csv" file to table newzealand_earthquakes_data

Edit db connection parameters in index.js file.

######################################################################