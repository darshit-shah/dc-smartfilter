var utils = require('axiom-utils');

var objReqStack = {};
var requestToken = 0;
var objSmartFilters = {};

function smartFilterRequest(action, requestData, connection, cb) {
  requestToken++;
  var localRequestToken = requestToken;
  objReqStack[localRequestToken.toString()] = {
    requestData: requestData,
    connection: connection,
    cb: cb
  };
  if (action.toString().toLowerCase() == "connect") { //connect to datasource
    requestData.reference = utils.uuid();
    var sf = require('child_process').fork(__dirname + '/smartfilterService.js');
    sf.on("message", function(output) {
      output.reference = objReqStack[output.input.requestToken].requestData.reference;
      objReqStack[output.input.requestToken].cb({
        status: true,
        content: {
          result: output
        }
      });
      delete objReqStack[output.input.requestToken];
    });

    objSmartFilters[requestData.reference] = sf;

    if (!connection.hasOwnProperty('smartFilter')) {
      connection.smartFilter = [];
    }
    connection.smartFilter.push(requestData.reference);

    var data = {};
    data.tableName = requestData.tableName;
    //var dbConfig = { type: "database", databaseType: 'mysql', database: json.dbCon.DATABASE, host: json.dbCon.HOST_NAME, port: json.dbCon.PORT, user: json.dbCon.MYSQL_USER, password: json.dbCon.MYSQL_PASS, multipleStatements: false };

    //VRP on 11th Dec : Commented this line
    //data.dbConfig = JSON.parse(requestData.dbConfig);
    data.dbConfig = requestData.dbConfig;
    objSmartFilters[requestData.reference].send({
      type: "connect",
      data: data,
      requestToken: localRequestToken.toString()
    });
  } else {
    if (requestData.reference == undefined) {
      objReqStack[localRequestToken].cb({
        status: false,
        content: {
          type: 'errorMessage',
          data: 'Reference not provided'
        }
      })
      delete objReqStack[localRequestToken];
      return;
    }
    if (action.toString().toLowerCase() == "disconnect") { //disconnect from data source and kill child process
      if (objSmartFilters[requestData.reference]) {
        objSmartFilters[requestData.reference].send({
          type: "disconnect",
          data: requestData.data
        });
        setTimeout(function() {
          objSmartFilters[requestData.reference].disconnect();
          objSmartFilters[requestData.reference] = null;
          delete objSmartFilters[requestData.reference];
        }, 250);
      }
      objReqStack[localRequestToken].cb({
        status: true,
        content: {
          result: "disconnected"
        }
      });
      delete objReqStack[localRequestToken];
      return;
    } else { //forward request for processing
      if (action.toString().toLowerCase() == "pivot") {
        if (!requestData.data.hasOwnProperty('dimensions')) {
          requestData.data['dimensions'] = [];
        }
      }
      if (objSmartFilters[requestData.reference]) {
        objSmartFilters[requestData.reference].send({
          type: action,
          data: requestData.data,
          requestToken: localRequestToken
        });
      }
    }
  }
}

var sf = {};
sf.connect = function(requestData, connection, cb) {
  smartFilterRequest('connect', requestData, connection, cb);
};
sf.pivot = function(requestData, connection, cb) {
  smartFilterRequest('pivot', requestData, connection, cb);
};
sf.filter = function(requestData, connection, cb) {
  smartFilterRequest('filter', requestData, connection, cb);
};
sf.staticFilter = function(requestData, connection, cb) {
  smartFilterRequest('staticFilter', requestData, connection, cb);
};
sf.removePivot = function(requestData, connection, cb) {
  smartFilterRequest('removePivot', requestData, connection, cb);
};
sf.count = function(requestData, connection, cb) {
  smartFilterRequest('count', requestData, connection, cb);
};
sf.data = function(requestData, connection, cb) {
  smartFilterRequest('data', requestData, connection, cb);
};
sf.flushCache = function(requestData, connection, cb) {
  smartFilterRequest('flushCache', requestData, connection, cb);
};
sf.disconnect = function(requestData, connection, cb) {
  smartFilterRequest('disconnect', requestData, connection, cb);
};
module.exports = sf;